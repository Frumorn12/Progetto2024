--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE web_app;
--
-- Name: web_app; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE web_app WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE web_app OWNER TO postgres;

\connect web_app

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: carrello; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carrello (
    utente character varying NOT NULL,
    nome character varying NOT NULL,
    prezzo double precision NOT NULL,
    quantita integer
);


ALTER TABLE public.carrello OWNER TO postgres;

--
-- Name: hamburger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hamburger (
    utente character varying NOT NULL,
    nome character varying NOT NULL,
    prezzo double precision NOT NULL,
    quantita integer NOT NULL,
    ordine integer NOT NULL
);


ALTER TABLE public.hamburger OWNER TO postgres;

--
-- Name: hamburger_ordine_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hamburger_ordine_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hamburger_ordine_seq OWNER TO postgres;

--
-- Name: hamburger_ordine_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hamburger_ordine_seq OWNED BY public.hamburger.ordine;


--
-- Name: ingredienti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingredienti (
    nome character varying NOT NULL,
    prezzo double precision NOT NULL,
    immagine character varying NOT NULL,
    tipo character varying NOT NULL
);


ALTER TABLE public.ingredienti OWNER TO postgres;

--
-- Name: piatti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.piatti (
    nome character varying NOT NULL,
    ingredienti character varying NOT NULL,
    descrizione character varying NOT NULL,
    preparazione character varying NOT NULL,
    tipo character varying NOT NULL,
    immagine character varying NOT NULL,
    prezzo double precision
);


ALTER TABLE public.piatti OWNER TO postgres;

--
-- Name: preferiti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preferiti (
    utente character varying NOT NULL,
    piatto character varying NOT NULL,
    stato boolean NOT NULL
);


ALTER TABLE public.preferiti OWNER TO postgres;

--
-- Name: recensioni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensioni (
    utente character varying NOT NULL,
    piatto character varying NOT NULL,
    recensione character varying NOT NULL,
    recensito boolean NOT NULL
);


ALTER TABLE public.recensioni OWNER TO postgres;

--
-- Name: utenti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utenti (
    username character varying NOT NULL,
    password character varying NOT NULL,
    tipo numeric NOT NULL,
    nome character varying,
    cognome character varying,
    data character varying,
    via character varying,
    civico integer,
    email character varying
);


ALTER TABLE public.utenti OWNER TO postgres;

--
-- Name: hamburger ordine; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hamburger ALTER COLUMN ordine SET DEFAULT nextval('public.hamburger_ordine_seq'::regclass);


--
-- Data for Name: carrello; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carrello (utente, nome, prezzo, quantita) FROM stdin;
\.
COPY public.carrello (utente, nome, prezzo, quantita) FROM '$$PATH$$/4867.dat';

--
-- Data for Name: hamburger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hamburger (utente, nome, prezzo, quantita, ordine) FROM stdin;
\.
COPY public.hamburger (utente, nome, prezzo, quantita, ordine) FROM '$$PATH$$/4868.dat';

--
-- Data for Name: ingredienti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingredienti (nome, prezzo, immagine, tipo) FROM stdin;
\.
COPY public.ingredienti (nome, prezzo, immagine, tipo) FROM '$$PATH$$/4869.dat';

--
-- Data for Name: piatti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.piatti (nome, ingredienti, descrizione, preparazione, tipo, immagine, prezzo) FROM stdin;
\.
COPY public.piatti (nome, ingredienti, descrizione, preparazione, tipo, immagine, prezzo) FROM '$$PATH$$/4865.dat';

--
-- Data for Name: preferiti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preferiti (utente, piatto, stato) FROM stdin;
\.
COPY public.preferiti (utente, piatto, stato) FROM '$$PATH$$/4866.dat';

--
-- Data for Name: recensioni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensioni (utente, piatto, recensione, recensito) FROM stdin;
\.
COPY public.recensioni (utente, piatto, recensione, recensito) FROM '$$PATH$$/4870.dat';

--
-- Data for Name: utenti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utenti (username, password, tipo, nome, cognome, data, via, civico, email) FROM stdin;
\.
COPY public.utenti (username, password, tipo, nome, cognome, data, via, civico, email) FROM '$$PATH$$/4864.dat';

--
-- Name: hamburger_ordine_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hamburger_ordine_seq', 25, true);


--
-- Name: hamburger hamburger_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hamburger
    ADD CONSTRAINT hamburger_pk PRIMARY KEY (ordine);


--
-- Name: ingredienti ingredienti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredienti
    ADD CONSTRAINT ingredienti_pk PRIMARY KEY (nome);


--
-- Name: piatti piatti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piatti
    ADD CONSTRAINT piatti_pk PRIMARY KEY (nome);


--
-- Name: utenti utenti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utenti
    ADD CONSTRAINT utenti_pk PRIMARY KEY (username);


--
-- PostgreSQL database dump complete
--

